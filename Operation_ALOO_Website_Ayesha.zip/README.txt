OPERATION ALOO 🥔💗

Files:
- index.html: Complete responsive website. No installation or external libraries required.

Test on your computer:
1. Extract the ZIP.
2. Open index.html in Chrome or any modern browser.

Share it online for free (Netlify Drop):
1. Open https://app.netlify.com/drop
2. Sign in if prompted.
3. Upload the extracted folder (or drag index.html if the page accepts it).
4. Netlify will provide a public link you can send to Aayat.

To change the name:
Open index.html in Notepad and use Ctrl+H to replace "Ayesha" with the spelling you prefer.
